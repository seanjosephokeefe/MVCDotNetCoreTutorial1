﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Calculator.Models;

namespace Calculator.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(String number1, String number2)
        {
            Decimal num1 = Decimal.Parse(number1);
            Decimal num2 = Decimal.Parse(number2);
            ViewData["num1"] = num1;
            ViewData["num2"] = num2;
            ViewData["sum"] = num1 + num2;
            ViewData["difference"] = num1 - num2;
            ViewData["product"] = num1 * num2;
            ViewData["quotient"] = "Quotient: Cannot divide by zero!!!";
            if (num2 != 0m)
            {
                ViewData["quotient"] = num1 / num2;
            }
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
